# Ranjith Devaraj — Digital Marketing Portfolio

GitHub Pages-ready static portfolio for Ranjith Devaraj.

## Publish on GitHub Pages

1. Create a new GitHub repository, for example `ranjith-portfolio`.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save. GitHub will provide your portfolio URL.

## Personalize

- Add your LinkedIn URL to the contact section.
- Add a project screenshot/case-study image if available.
- Replace the initials card with a professional profile photo if desired.
